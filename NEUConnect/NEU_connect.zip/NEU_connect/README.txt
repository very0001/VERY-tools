东北大学校园网连接与认证（Python 源码）

先安装 Python 和 Microsoft Edge，在终端运行：py -m pip install playwright
手动连接一次 NEU，让电脑保存 Wi-Fi。用记事本打开 config.json，填入学号和统一认证密码；也可以留空，在网页手动登录。
双击 neu_connect.pyw 运行，或者用 pyw neu_connect.pyw 启动。运行时不显示终端，认证网页仍会打开。约 6 秒内没连上 NEU 就会自动退出。运行记录在 %LOCALAPPDATA%\NEUConnect\neu_connect.log。
密码以明文保存在 config.json，不要分享填写过的文件。设置自启时，把 neu_connect.pyw 的快捷方式放进 shell:startup 打开的文件夹。
