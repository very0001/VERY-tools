@echo off
cd /d "%~dp0"
py neu_connect.py
