# -*- coding: utf-8 -*-
"""Connect to saved NEU Wi-Fi and authenticate on the campus portal."""
import os
import subprocess
import time
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

# 在自己电脑上填写；密码以明文保存，请勿分享填好的文件。
USERNAME = ''
PASSWORD = ''
WIFI_PROFILE = 'NEU'  # Windows 中已保存的 Wi-Fi 配置文件名
ROOT = Path(os.environ['LOCALAPPDATA']) / 'NEUConnect'
PROFILE = ROOT / 'EdgeProfile'
PORTAL = 'https://ipgw.neu.edu.cn/srun_portal_pc?ac_id=16&theme=pro'

def command(*args):
    return subprocess.run(args, capture_output=True, text=True, encoding='oem', errors='replace', timeout=20)

def wifi_connected():
    result = command('netsh', 'wlan', 'show', 'interfaces')
    for line in result.stdout.splitlines():
        parts = line.split(':', 1)
        if len(parts) == 2 and parts[0].strip() == 'SSID' and parts[1].strip() == WIFI_PROFILE:
            return True
    return False

def connect_wifi():
    # 登录后无线服务可能尚未就绪，等待并重试。
    until = time.monotonic() + 90
    next_attempt = 0.0
    while time.monotonic() < until:
        try:
            if wifi_connected():
                return
            if time.monotonic() >= next_attempt:
                command('netsh', 'wlan', 'connect', f'name={WIFI_PROFILE}', f'ssid={WIFI_PROFILE}')
                next_attempt = time.monotonic() + 15
        except (OSError, subprocess.TimeoutExpired):
            pass
        time.sleep(3)
    raise RuntimeError('NEU did not connect within 90 seconds. Check Wi-Fi and its saved profile.')

def is_sso(page):
    u = urlparse(page.url)
    return u.scheme == 'https' and u.hostname == 'pass.neu.edu.cn'

def success(page):
    try:
        u = urlparse(page.url)
        return u.hostname == 'ipgw.neu.edu.cn' and page.get_by_text('网络已连接', exact=True).is_visible()
    except Exception:
        return False

def authenticate():
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(str(PROFILE), channel='msedge', headless=False, args=['--no-proxy-server'], ignore_default_args=['--no-sandbox'])
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        try:
            page.goto(PORTAL, wait_until='domcontentloaded', timeout=45000)
            deadline = time.monotonic() + 90
            submitted = False
            connect_clicked = False
            while time.monotonic() < deadline:
                for candidate in ctx.pages:
                    if success(candidate):
                        print('NEU portal confirms network connected.')
                        return True
                    u = urlparse(candidate.url)
                    if (not connect_clicked and u.scheme == 'https' and
                            u.hostname == 'ipgw.neu.edu.cn'):
                        try:
                            button = candidate.get_by_text('连接网络', exact=True)
                            if button.is_visible():
                                button.click(timeout=3000, no_wait_after=True)
                                connect_clicked = True
                                print('Clicked Connect Network.')
                        except PlaywrightTimeoutError:
                            pass
                    if not submitted and is_sso(candidate):
                        try:
                            user = candidate.get_by_placeholder('工资号/学号')
                            if user.is_visible():
                                if not USERNAME or not PASSWORD:
                                    print('Enter credentials manually in the browser; waiting up to 90 seconds.')
                                    submitted = True
                                else:
                                    user.fill(USERNAME, timeout=10000)
                                    candidate.get_by_placeholder('输入密码').fill(PASSWORD, timeout=10000)
                                    if not is_sso(candidate): raise RuntimeError('Unexpected login origin.')
                                    candidate.get_by_role('button', name='登录', exact=True).click(timeout=10000)
                                    print('Login submitted once; awaiting confirmation.')
                                    submitted = True
                        except PlaywrightTimeoutError:
                            pass
                time.sleep(1)
            print('Authentication was not confirmed. Check the browser.')
            input('Press Enter after checking the page...')
            return False
        finally:
            ctx.close()

if __name__ == '__main__':
    try:
        print('Connecting to NEU Wi-Fi...')
        connect_wifi()
        print('Connected to NEU. Starting authentication...')
        if authenticate():
            print('Done: the NEU portal reports network connected.')
        else:
            print('Authentication was not confirmed.')
    except Exception as exc:
        print('Stopped:', str(exc))
        input('Press Enter to close...')
