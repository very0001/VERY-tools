﻿东北大学校园网连接与认证

先手动连接一次 NEU，让电脑保存这个 Wi-Fi。用记事本打开 config.json，在引号里填写自己的学号和统一认证密码并保存。也可以留空，等网页打开后手动登录。

双击 NEUConnect.exe 运行。程序不会显示黑色终端窗口；连接上 NEU 后会打开 Edge 认证网页。如果需要验证码，请手动完成。页面显示“网络已连接”才表示认证成功。

如果约 60 秒内没有连上 NEU，程序会自动退出。运行记录保存在 %LOCALAPPDATA%\NEUConnect\neu_connect.log，每次运行会覆盖上次记录。密码明文保存在 config.json 中，不要分享填写过的文件。

这个版本需要 Microsoft Edge，不需要安装 Python。设置自启时，先测试程序，再按 Win+R 输入 shell:startup，把程序的快捷方式放进打开的文件夹。整个解压文件夹需要放在固定位置。
